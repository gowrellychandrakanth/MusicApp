//
//  ListOfMusicCustomCell.swift
//  MusicPalyerApp
//
//  Created by Maneet Singh on 30/05/17.
//  Copyright © 2017 chandrakanth. All rights reserved.
//

import UIKit
import MediaPlayer

class ListOfMusicCustomCell: UITableViewCell {

    @IBOutlet weak var imageForMusic: UIImageView!
    @IBOutlet weak var nameOfTheSong: UILabel!
    @IBOutlet weak var singerTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
