//
//  ListOfMusicFiles.swift
//  MusicPalyerApp
//
//  Created by Maneet Singh on 30/05/17.
//  Copyright © 2017 chandrakanth. All rights reserved.
//

import UIKit
import MediaPlayer

class ListOfMusicFiles: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var appDele = AppDelegate()
    @IBOutlet weak var listMusic_TV: UITableView!
    var artists = NSMutableArray()
    var artistAlbum = NSDictionary()
    override func viewDidLoad() {
        super.viewDidLoad()
       self.appDele = UIApplication.shared.delegate as! AppDelegate
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        listMusic_TV.delegate = self
        listMusic_TV.dataSource = self
        self.requestAuth()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if artists.count == 0
        {
            return 0
        }
        else{
            return artists.count
        }
    }

    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = self.listMusic_TV.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as! ListOfMusicCustomCell
        cell.nameOfTheSong.sizeToFit()
        cell.singerTitle.sizeToFit()
        cell.nameOfTheSong.text = ((((artists.object(at: indexPath.row)as! NSDictionary).object(forKey: "songs") as! NSArray).object(at: 0) as! NSDictionary).object(forKey: "title") as! String)
        cell.singerTitle.text = ((artists.object(at: indexPath.row)as! NSDictionary).object(forKey: "artist")as! String)
       cell.imageForMusic.image = ((((artists.object(at: indexPath.row)as? NSDictionary)?.object(forKey: "songs") as? NSArray)?.object(at: 0) as? NSDictionary)?.object(forKey: "ImageArt") as? MPMediaItemArtwork )?.image(at: CGSize(width: cell.imageForMusic.frame.width, height: cell.imageForMusic.frame.height)) ?? #imageLiteral(resourceName: "Music-placeholder") ;
        
        return cell
    }
    
     public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
     {
        self.appDele.player.pause()
        let playMySong = self.storyboard?.instantiateViewController(withIdentifier: "PlayMySongView") as! PlayMySongView
        playMySong.artistsWithData = artists
        self.appDele.myCurrentIndex = indexPath.row
      
        self.navigationController?.pushViewController(playMySong, animated: true)
     }
    
    //MARK: - Helper methods
    
    fileprivate func requestAuth() {
        
        MPMediaLibrary.requestAuthorization { (authStatus) in
            switch authStatus {
            case .notDetermined:
                self.requestAuth()
                break
            case .authorized:
                self.querySongs()
                break
            default:
                self.displayPermissionsError()
                break
                
            }
        }
    }
    
    fileprivate func querySongs() {
        
        title = "Querying..."
        queryForSongs {(result:NSDictionary?) in
            if let nonNilResult = result {
                artists = nonNilResult["artists"]  as! NSMutableArray
                let songCount = nonNilResult["songCount"] as! Int
                DispatchQueue.main.async {
                    self.title = "Songs (\(songCount))"
                    self.listMusic_TV.reloadData()
                }
            }
        }
        
    }
    
    fileprivate func displayPermissionsError() {
        let alertVC = UIAlertController(title: "MusicPlayer", message: "Unauthorized or restricted access. Cannot play media. Fix in Settings?" , preferredStyle: .alert)
        
        //cancel
        if let settingsURL = URL(string: UIApplicationOpenSettingsURLString), UIApplication.shared.canOpenURL(settingsURL) {
            alertVC.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler:nil))
            let settingsAction = UIAlertAction(title: "Settings", style: .default, handler: { (action) in
                UIApplication.shared.openURL(settingsURL)
            })
            alertVC.addAction(settingsAction)
        } else {
            alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler:nil))
        }
        present(alertVC, animated: true, completion: nil)
    }
    
    func queryForSongs(_ completionHandler:(_ result:NSDictionary) -> Void)
    {
        let query = MPMediaQuery.artists()
        let songsByArtist = query.collections! as [MPMediaItemCollection]
        
        var songCount = 0
        
        let albumSortingDictionary:NSMutableDictionary = NSMutableDictionary()
        
        for album in songsByArtist {
            let albumSongs = album.items as [MPMediaItem]
            for songMediumItem in albumSongs {
                let artistName:String = songMediumItem.value(forProperty: MPMediaItemPropertyArtist) as? String ?? ""
                let artishImage: AnyObject = songMediumItem.value(forProperty: MPMediaItemPropertyArtwork) as AnyObject
                let albumName:String = songMediumItem.value(forProperty: MPMediaItemPropertyAlbumTitle) as? String ?? ""
                let songTitle:String = songMediumItem.value(forProperty: MPMediaItemPropertyTitle) as? String ?? ""
                let songId:NSNumber = songMediumItem.value(forProperty: MPMediaItemPropertyPersistentID) as! NSNumber
                let assetUrl:URL = (songMediumItem.value(forProperty:MPMediaItemPropertyAssetURL) as? URL)!
                var artistAlbum = albumSortingDictionary.object(forKey: albumName) as? NSDictionary
                if (artistAlbum == nil) {
                    artistAlbum = NSDictionary(objects: [artistName,albumName,NSMutableArray()], forKeys: ["artist" as NSCopying,"album" as NSCopying,"songs" as NSCopying,])
                    albumSortingDictionary[albumName] = artistAlbum
                }
                
                let songs:NSMutableArray = artistAlbum!["songs"] as! NSMutableArray
                let song:NSDictionary = ["title":songTitle, "songId":songId, "ImageArt" : artishImage, "assetURL" : assetUrl]
                songs.add(song)
                songCount += 1
            }
            //sort by AlbumName
            let sortedAlbumsByName = albumSortingDictionary.keysSortedByValue(comparator: { (obj1:Any! , obj2:Any!) -> ComparisonResult in
                let one = obj1 as! NSDictionary
                let two = obj2 as! NSDictionary
                return (one["album"] as! String).localizedCaseInsensitiveCompare((two["album"] as! String))
            })
            
            for album in sortedAlbumsByName {
                let artistAlbum = albumSortingDictionary[(album as! String)]
                artists.add(artistAlbum as AnyObject)
            }
            
            albumSortingDictionary.removeAllObjects()
        }
        DispatchQueue.main.async {
            self.listMusic_TV.reloadData()
        }
        
    }

}
