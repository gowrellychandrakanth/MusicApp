//
//  PlayMySongView.swift
//  MusicPalyerApp
//
//  Created by Maneet Singh on 31/05/17.
//  Copyright © 2017 chandrakanth. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer
import AVKit

class PlayMySongView: UIViewController,AVAudioPlayerDelegate {

    let avQueuePlayer:AVQueuePlayer = AVQueuePlayer()
    var appDele = AppDelegate()
    var artistsWithData = NSMutableArray()
    
    @IBOutlet weak var songImage: UIImageView!
    @IBOutlet weak var playBtn: UIButton!
    @IBOutlet weak var forwardBtn: UIButton!
    @IBOutlet weak var rewinedBtn: UIButton!
    @IBOutlet weak var titleOfSong: UILabel!
    @IBOutlet weak var endTimer: UILabel!
    @IBOutlet weak var startTimer: UILabel!
    @IBOutlet weak var progressSlider: UISlider!
    var timer = Timer()
    var isCheckSong = Bool()
    
    override func viewDidLoad() {
        self.appDele = UIApplication.shared.delegate as! AppDelegate
        NotificationCenter.default.addObserver(self, selector: #selector(PlayMySongView.audioSessionInterrupted(_:)), name: NSNotification.Name.AVAudioSessionInterruption, object: AVAudioSession.sharedInstance())
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            let _ = try AVAudioSession.sharedInstance().setActive(true)
        } catch let error as NSError {
            print("an error occurred when audio session category.\n \(error)")
        }

    }
    
    class func audioSessionInterrupted(_ notification:Notification)
    {
        print("interruption received: \(notification)")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        playBtn.isSelected = false
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.myProfileUpdate()
        
    }

    @IBAction func playForwardAndRewinedBtn(_ sender: UIButton)
    {
        switch sender {
        case playBtn:
            if playBtn.isSelected != true
            {
                playBtn.isSelected = true
                self.appDele.player.pause()
                isCheckSong = true
            }
            else{
                playBtn.isSelected = false
                self.appDele.player.play()
            }
        case forwardBtn:
            self.forwardMusic()
        case rewinedBtn:
            self.rewinedMusic()
        default:
            break
        }
    }
    
    @IBAction func backButtonAction(_ sender: UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func myProfileUpdate() {
        if self.appDele.myCurrentIndex == 0
        {
            self.rewinedBtn.isEnabled = false
        }
        
        songImage.image = ((((artistsWithData.object(at: self.appDele.myCurrentIndex)as? NSDictionary)?.object(forKey: "songs") as? NSArray)?.object(at: 0) as? NSDictionary)?.object(forKey: "ImageArt") as? MPMediaItemArtwork )?.image(at: CGSize(width: songImage.frame.width, height: songImage.frame.height)) ?? #imageLiteral(resourceName: "Music-placeholder")
        
        titleOfSong.text = ((((artistsWithData.object(at: self.appDele.myCurrentIndex)as! NSDictionary).object(forKey: "songs") as! NSArray).object(at: 0) as! NSDictionary).object(forKey: "title") as! String)
        
        let assetURl : URL = ((((artistsWithData.object(at: self.appDele.myCurrentIndex)as? NSDictionary)?.object(forKey: "songs") as? NSArray)?.object(at: 0) as? NSDictionary)?.object(forKey: "assetURL") as! URL )
        
        UIApplication.shared.beginReceivingRemoteControlEvents()
        self.becomeFirstResponder()
        
        self.appDele.player.pause()
        self.appDele.player = AVPlayer(url:assetURl)
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(update), userInfo: nil, repeats: true);
        progressSlider.maximumValue = Float(self.durationInSeconds())
        progressSlider.minimumValue = 0.0
        progressSlider.isContinuous = true
        
        self.appDele.player.volume=1.0
        
        let playerLayer = AVPlayerLayer(player: self.appDele.player)
        
        playerLayer.frame = self.view.bounds
        self.view.layer.addSublayer(playerLayer)
        
        self.appDele.player.play()
    }
    
    func update()
    {
        progressSlider.value = Float(self.currentTimeInSeconds())
        
        if Float(self.currentTimeInSeconds()) == Float(self.durationInSeconds())
        {
            self.appDele.myCurrentIndex = self.appDele.myCurrentIndex+1
            self.myProfileUpdate()
            progressSlider.minimumValue = Float(self.currentTimeInSeconds())
        }
    
        let fomarter:DateComponentsFormatter = DateComponentsFormatter();
        fomarter.unitsStyle = .positional;
        fomarter.allowedUnits = [.minute , .second]
        fomarter.zeroFormattingBehavior = .pad;
        startTimer.text = fomarter.string(from: self.currentTimeInSeconds())
        endTimer.text =  fomarter.string(from: Float64(self.durationInSeconds() - self.currentTimeInSeconds()))
    }
    
    @IBAction func sliderMovingAction(_ sender: UISlider)
    {
        let desiredTime : CMTime = CMTimeMakeWithSeconds(Float64(progressSlider.value),1);
        self.appDele.player.seek(to: desiredTime, toleranceBefore: kCMTimeZero, toleranceAfter: kCMTimeZero) { (Bool) in
            if self.isCheckSong == false
            {
                self.appDele.player.play()
            }
        }
    }
    
    func durationInSeconds() -> Float64 {
        let duration = CMTimeGetSeconds((self.appDele.player.currentItem?.asset.duration)!)
        return duration
    }
    
    func currentTimeInSeconds() -> Float64 {
        let duaration = CMTimeGetSeconds(self.appDele.player.currentTime())
        return duaration
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        UIApplication.shared.endReceivingRemoteControlEvents()
        self.becomeFirstResponder()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        self.appDele.player.play()
    }
    // MARK: -
    //MARK: - events received from phone
    
    func remoteControlReceivedWithEvent(recivedEvent: UIEvent?) {
        
        
        if (recivedEvent?.type == .remoteControl) {
            switch recivedEvent!.subtype {
            case .remoteControlTogglePlayPause:
                if self.appDele.player.rate > 0.0 {
                    self.appDele.player.pause()
                } else {
                    self.appDele.player.play()
                }
            case .remoteControlPlay:
                self.appDele.player.play()
            case .remoteControlPause:
                self.appDele.player.pause()
            case .remoteControlNextTrack:
                self.forwardMusic()
            case .remoteControlPreviousTrack:
                rewinedMusic()
            default:
                print("received sub type \(String(describing: recivedEvent?.subtype)) Ignoring")
            }
        }
    }
    
    override func remoteControlReceived(with event: UIEvent?) {
        self.remoteControlReceivedWithEvent(recivedEvent: event)
        
    }

    func forwardMusic() {
        if self.appDele.myCurrentIndex == artistsWithData.count-1
        {
            self.forwardBtn.isEnabled = false
            self.rewinedBtn.isEnabled = true
            self.myProfileUpdate()
            self.progressSlider.minimumValue = Float(self.currentTimeInSeconds())
        }
        else{
            self.appDele.myCurrentIndex = self.appDele.myCurrentIndex+1
            self.rewinedBtn.isEnabled = true
            self.myProfileUpdate()
            self.progressSlider.minimumValue = Float(self.currentTimeInSeconds())
        }
    }
    
    func rewinedMusic() {
        if self.appDele.myCurrentIndex == 0
        {
            self.rewinedBtn.isEnabled = false
        }
        else{
            self.appDele.myCurrentIndex = self.appDele.myCurrentIndex-1
            if self.appDele.myCurrentIndex == 0
            {
                self.rewinedBtn.isEnabled = false
            }
            
            self.myProfileUpdate()
            progressSlider.minimumValue = Float(self.currentTimeInSeconds())
        }
    }
}
