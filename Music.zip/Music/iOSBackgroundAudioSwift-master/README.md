iOSBackgroundAudioSwift
==================

Sample iOS 8 code (Swift) for playing audio in the background. 
 - Demonstrates iTunes music queries, playing songs, and remote control events received in the control center.
For more details, see this blog post: http://www.sagorin.org/ios-playing-audio-in-background-audio/

Run code on a device with some music (no songs in the iOS simulator)

For the Objective-C version of this code, see https://github.com/jsagorin/iOSBackgroundAudio
